package org.example.battleship.model;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.testng.Assert.*;

public class CoordinateTest {

    /*@Test
    public void testPlus(){
        Assert.assertEquals();
    }

    @Test
    public void testPlusColumn(){
        Assert.assertEquals();
    }

    @Test
    public void testPlusRow(){
        Assert.assertEquals();
    }*/
}