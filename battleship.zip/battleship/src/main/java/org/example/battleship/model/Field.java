package org.example.battleship.model;

public enum Field {
    SHIP, SHIP_HIT, WATER, WATER_HIT;
}
