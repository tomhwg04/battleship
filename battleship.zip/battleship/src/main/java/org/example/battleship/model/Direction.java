package org.example.battleship.model;

public enum Direction {
    EAST, NORTH, SOUTH, WEST;
}
